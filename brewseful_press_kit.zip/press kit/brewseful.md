# Brewseful
## A simple timer app for brewing coffee. Now available for free on the apple app store.

Designed and developed by Kevin Zweerink
www.kevinzweerink.com

Features:
- Custom timer with bold progress indicator
- In-timer reminders to mark times for stirring, pouring, etc
- Built-in calculator for water to grounds ratios
- Save timer configurations for later use

Demo Video:
http://vimeo.com/92414341

Official Site:
http://www.brewseful.com

Inquiries:
kevinzweerink@gmail.com